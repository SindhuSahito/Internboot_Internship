import { useAuth } from "../hooks/useAuth";

export default function Dashboard() {
  const { currentUser } = useAuth();

  return (
    <div>
      <h1 className="text-3xl font-bold">
        Welcome 👋
      </h1>

      <p className="mt-3 text-gray-600">
        Hello,
        <span className="font-semibold">
          {" "}
          {currentUser?.displayName ||
            currentUser?.email ||
            "User"}
        </span>
      </p>

      <div className="grid md:grid-cols-3 gap-6 mt-10">
        <div className="bg-blue-100 rounded-xl p-6">
          <h2 className="text-lg font-semibold">
            Profile
          </h2>

          <p className="text-gray-600 mt-2">
            Complete your profile information.
          </p>
        </div>

        <div className="bg-green-100 rounded-xl p-6">
          <h2 className="text-lg font-semibold">
            Projects
          </h2>

          <p className="text-gray-600 mt-2">
            Add and manage your portfolio projects.
          </p>
        </div>

        <div className="bg-purple-100 rounded-xl p-6">
          <h2 className="text-lg font-semibold">
            Templates
          </h2>

          <p className="text-gray-600 mt-2">
            Select your favorite portfolio design.
          </p>
        </div>
      </div>
    </div>
  );
}