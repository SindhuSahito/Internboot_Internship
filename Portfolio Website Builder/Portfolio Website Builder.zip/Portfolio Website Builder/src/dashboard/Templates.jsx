import { useState } from "react";
image: "https://picsum.photos/600/400?random=1"

// import ModernTemplate from "../components/templates/ModernTemplate";
// import CreativeTemplate from "../components/templates/CreativeTemplate";
// import SidebarTemplate from "../components/templates/SidebarTemplate";

export default function Templates() {
  const [selected, setSelected] = useState("modern");

  const templates = [
    {
      id: "modern",
      title: "Modern Minimal",
      component: <ModernTemplate />,
    },
    {
      id: "creative",
      title: "Creative Grid",
      component: <CreativeTemplate />,
    },
    {
      id: "sidebar",
      title: "Sidebar Focus",
      component: <SidebarTemplate />,
    },
  ];

  return (
    <div className="p-6">

      <h1 className="text-3xl font-bold mb-8">
        Choose Your Portfolio Template
      </h1>

      <div className="grid lg:grid-cols-3 gap-8">

        {templates.map((template) => (

          <div
            key={template.id}
            onClick={() => setSelected(template.id)}
            className={`cursor-pointer rounded-xl transition ${
              selected === template.id
                ? "ring-4 ring-blue-600 scale-105"
                : "hover:scale-105"
            }`}
          >

            {template.component}

            <div className="text-center mt-4">

              <h2 className="font-bold text-lg">
                {template.title}
              </h2>

            </div>

          </div>

        ))}

      </div>

      <button className="mt-10 bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700">
        Save Selected Template
      </button>

    </div>
  );
}