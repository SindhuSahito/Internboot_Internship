import ProfileForm from "../components/profile/ProfileForm";

export default function Profile() {
  return (
    <>
      <h1 className="text-3xl font-bold mb-6">
        My Profile
      </h1>

      <div className="bg-white rounded-xl shadow p-8">
        <ProfileForm />
      </div>
    </>
  );
}