import { useEffect, useState } from "react";
import { useAuth } from "../hooks/useAuth";

import {
  getProjects,
  addProject,
  updateProject,
  deleteProject,
} from "../services/projectService";

import { uploadProjectImage } from "../services/storageService";

import ProjectModal from "../components/projects/ProjectModal";
import ProjectForm from "../components/projects/ProjectForm";
import ProjectCard from "../components/projects/ProjectCard";

export default function Projects() {
  const { currentUser } = useAuth();

  const [projects, setProjects] = useState([]);
  const [openModal, setOpenModal] = useState(false);
  const [editingProject, setEditingProject] = useState(null);
  const [loading, setLoading] = useState(true);

  async function loadProjects() {
    if (!currentUser) return;

    try {
      const data = await getProjects(currentUser.uid);
      setProjects(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadProjects();
  }, [currentUser]);

  async function handleSaveProject(data) {
    try {
      let imageUrl = editingProject?.image || "";

      if (data.image) {
        imageUrl = await uploadProjectImage(
          currentUser.uid,
          data.image
        );
      }

      const projectData = {
        title: data.title,
        description: data.description,
        github: data.github,
        liveDemo: data.liveDemo,
        featured: data.featured,
        image: imageUrl,
        tags: data.tags
          ? data.tags
              .split(",")
              .map((tag) => tag.trim())
              .filter(Boolean)
          : [],
      };

      if (editingProject) {
        await updateProject(
          currentUser.uid,
          editingProject.id,
          projectData
        );
      } else {
        await addProject(currentUser.uid, projectData);
      }

      setEditingProject(null);
      setOpenModal(false);

      loadProjects();
    } catch (error) {
      console.error(error);
      alert(error.message);
    }
  }

  async function handleDelete(id) {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this project?"
    );

    if (!confirmDelete) return;

    try {
      await deleteProject(currentUser.uid, id);

      loadProjects();
    } catch (error) {
      console.error(error);
    }
  }

  function handleEdit(project) {
    setEditingProject({
      ...project,
      tags: project.tags?.join(", ") || "",
    });

    setOpenModal(true);
  }

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">

        <div>
          <h1 className="text-3xl font-bold">
            My Projects
          </h1>

          <p className="text-gray-500 mt-1">
            Manage all of your portfolio projects.
          </p>
        </div>

        <button
          onClick={() => {
            setEditingProject(null);
            setOpenModal(true);
          }}
          className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-3 rounded-lg"
        >
          + Add Project
        </button>

      </div>

      {loading ? (
        <div className="text-center py-10">
          Loading Projects...
        </div>
      ) : projects.length === 0 ? (
        <div className="bg-white shadow rounded-xl p-12 text-center">
          <h2 className="text-2xl font-semibold">
            No Projects Yet
          </h2>

          <p className="text-gray-500 mt-3">
            Start building your portfolio by adding your first project.
          </p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
          {projects.map((project) => (
            <ProjectCard
              key={project.id}
              project={project}
              onEdit={handleEdit}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}

      <ProjectModal
        open={openModal}
        onClose={() => {
          setOpenModal(false);
          setEditingProject(null);
        }}
      >
        <ProjectForm
          defaultValues={editingProject || {}}
          onSubmit={handleSaveProject}
        />
      </ProjectModal>
    </div>
  );
}