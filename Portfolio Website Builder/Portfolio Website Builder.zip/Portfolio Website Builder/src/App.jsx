import { Routes, Route } from "react-router-dom";

// Public Pages
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Portfolio from "./pages/Portfolio";
import NotFound from "./pages/NotFound";

// Dashboard Pages
import Dashboard from "./dashboard/Dashboard";
import Profile from "./dashboard/Profile";
import Projects from "./dashboard/Projects";
import Templates from "./dashboard/Templates";

// Layout
import DashboardLayout from "./layouts/DashboardLayout";

// Route Protection
import PrivateRoute from "./routes/PrivateRoute";

function App() {
  return (
    <Routes>
      {/* ================= Public Routes ================= */}

      <Route path="/" element={<Home />} />

      <Route path="/login" element={<Login />} />

      <Route path="/register" element={<Register />} />

      {/* Public Portfolio */}
      <Route
        path="/portfolio/:username"
        element={<Portfolio />}
      />

      {/* ================= Dashboard ================= */}

      <Route
        path="/dashboard"
        element={
          <PrivateRoute>
            <DashboardLayout />
          </PrivateRoute>
        }
      >
        <Route index element={<Dashboard />} />

        <Route
          path="profile"
          element={<Profile />}
        />

        <Route
          path="projects"
          element={<Projects />}
        />

        <Route
          path="templates"
          element={<Templates />}
        />
      </Route>

      {/* ================= 404 ================= */}

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default App;