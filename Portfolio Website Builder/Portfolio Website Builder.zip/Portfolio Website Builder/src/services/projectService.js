import {
  collection,
  addDoc,
  getDocs,
  doc,
  updateDoc,
  deleteDoc,
  serverTimestamp,
  query,
  orderBy,
} from "firebase/firestore";

import { db } from "../firebase/firebase";

/**
 * Add New Project
 */
export async function addProject(uid, data) {
  const projectsRef = collection(db, "users", uid, "projects");

  await addDoc(projectsRef, {
    ...data,
    createdAt: serverTimestamp(),
  });
}

/**
 * Get All Projects
 */
export async function getProjects(uid) {
  const projectsRef = collection(db, "users", uid, "projects");

  const q = query(projectsRef, orderBy("createdAt", "desc"));

  const snapshot = await getDocs(q);

  return snapshot.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
  }));
}

/**
 * Update Project
 */
export async function updateProject(uid, projectId, data) {
  const projectRef = doc(
    db,
    "users",
    uid,
    "projects",
    projectId
  );

  await updateDoc(projectRef, {
    ...data,
  });
}

/**
 * Delete Project
 */
export async function deleteProject(uid, projectId) {
  const projectRef = doc(
    db,
    "users",
    uid,
    "projects",
    projectId
  );

  await deleteDoc(projectRef);
}