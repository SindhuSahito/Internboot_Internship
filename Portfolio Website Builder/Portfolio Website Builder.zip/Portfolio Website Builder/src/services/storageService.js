import {
  ref,
  uploadBytes,
  getDownloadURL,
  deleteObject,
} from "firebase/storage";

import { storage } from "../firebase/firebase";

/**
 * Upload Project Image
 */
export async function uploadProjectImage(uid, file) {
  if (!file) return "";

  const fileName = `${Date.now()}_${file.name}`;

  const storageRef = ref(
    storage,
    `projects/${uid}/${fileName}`
  );

  await uploadBytes(storageRef, file);

  return await getDownloadURL(storageRef);
}

/**
 * Upload Profile Image
 */
export async function uploadProfileImage(uid, file) {
  if (!file) return "";

  const fileName = `${Date.now()}_${file.name}`;

  const storageRef = ref(
    storage,
    `profiles/${uid}/${fileName}`
  );

  await uploadBytes(storageRef, file);

  return await getDownloadURL(storageRef);
}

/**
 * Delete Image From Storage
 */
export async function deleteImage(imageUrl) {
  try {
    const imageRef = ref(storage, imageUrl);
    await deleteObject(imageRef);
  } catch (error) {
    console.log(error);
  }
}