import {
  collection,
  getDocs,
} from "firebase/firestore";

import { db } from "../firebase/firebase";

export async function getPortfolioByUsername(username) {
  const usersSnapshot = await getDocs(collection(db, "users"));

  let userData = null;

  usersSnapshot.forEach((doc) => {
    const data = doc.data();

    if (data.username === username) {
      userData = {
        id: doc.id,
        ...data,
      };
    }
  });

  return userData;
}

export async function getPortfolioProjects(uid) {
  const snapshot = await getDocs(
    collection(db, "users", uid, "projects")
  );

  return snapshot.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
  }));
}