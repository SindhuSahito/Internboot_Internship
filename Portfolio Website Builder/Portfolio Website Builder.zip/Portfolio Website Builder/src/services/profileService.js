import {
  doc,
  setDoc,
  getDoc,
} from "firebase/firestore";

import { db } from "../firebase/firebase";

export async function createUserProfile(uid, data) {
  await setDoc(doc(db, "users", uid), data);
}

export async function getUserProfile(uid) {
  const snap = await getDoc(doc(db, "users", uid));

  if (snap.exists()) {
    return snap.data();
  }

  return null;
}

export async function updateUserProfile(uid, data) {
  await setDoc(
    doc(db, "users", uid),
    data,
    { merge: true }
  );
}

export async function saveTemplate(uid, template) {
  await setDoc(
    doc(db, "users", uid),
    {
      selectedTemplate: template,
    },
    { merge: true }
  );
}