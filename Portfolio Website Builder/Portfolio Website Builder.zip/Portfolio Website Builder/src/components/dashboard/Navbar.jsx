import { useAuth } from "../../hooks/useAuth";

export default function Navbar() {
  const { currentUser } = useAuth();

  return (
    <header className="bg-white shadow px-8 py-5 flex justify-between items-center">
      <div>
        <h2 className="text-2xl font-bold">
          Dashboard
        </h2>
      </div>

      <div className="flex items-center gap-3">
        <img
          src={
            currentUser?.photoURL ||
            "https://ui-avatars.com/api/?name=User"
          }
          alt="avatar"
          className="w-10 h-10 rounded-full"
        />

        <div>
          <p className="font-semibold">
            {currentUser?.displayName || "User"}
          </p>

          <p className="text-sm text-gray-500">
            {currentUser?.email}
          </p>
        </div>
      </div>
    </header>
  );
}