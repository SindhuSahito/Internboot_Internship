import { LayoutDashboard, User, FolderKanban, Palette, Globe, LogOut } from "lucide-react";
import { useAuth } from "../../hooks/useAuth";
import { NavLink, useNavigate } from "react-router-dom";


export default function Sidebar() {
  const { logout } = useAuth();

const navigate = useNavigate();

const handleLogout = async () => {
  await logout();
  navigate("/login");
};

  const menu = [
    {
      name: "Dashboard",
      icon: <LayoutDashboard size={20} />,
      path: "/dashboard",
    },
    {
      name: "Profile",
      icon: <User size={20} />,
      path: "/dashboard/profile",
    },
    {
      name: "Projects",
      icon: <FolderKanban size={20} />,
      path: "/dashboard/projects",
    },
    {
      name: "Templates",
      icon: <Palette size={20} />,
      path: "/dashboard/templates",
    },
    {
      name: "Portfolio",
      icon: <Globe size={20} />,
      path: "/dashboard/portfolio",
    },
  ];

  return (
    <aside className="w-64 bg-slate-900 text-white min-h-screen p-6">
      <h1 className="text-2xl font-bold mb-10">
        Portfolio Builder
      </h1>

      <nav className="space-y-3">
        {menu.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 rounded-lg transition ${
                isActive
                  ? "bg-blue-600"
                  : "hover:bg-slate-700"
              }`
            }
          >
            {item.icon}
            {item.name}
          </NavLink>
        ))}



        <button
        onClick={handleLogout}
          className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-red-600 transition w-full text-left mt-10"
        >
          <LogOut size={20} />

          Logout
        </button>



      </nav>
    </aside>
  );
}