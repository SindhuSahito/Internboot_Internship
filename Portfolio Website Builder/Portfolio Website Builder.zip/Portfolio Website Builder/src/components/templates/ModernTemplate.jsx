export default function ModernTemplate() {
  return (
    <div className="bg-white rounded-xl shadow overflow-hidden">

      <div className="bg-blue-600 h-24"></div>

      <div className="-mt-10 flex flex-col items-center">

        <div className="w-20 h-20 rounded-full bg-gray-300 border-4 border-white"></div>

        <h2 className="font-bold text-xl mt-3">
          John Doe
        </h2>

        <p className="text-gray-500 text-sm">
          Full Stack Developer
        </p>

      </div>

      <div className="p-5">

        <div className="space-y-2">

          <div className="h-3 bg-gray-200 rounded"></div>
          <div className="h-3 bg-gray-200 rounded w-3/4"></div>

        </div>

        <div className="grid grid-cols-2 gap-3 mt-6">

          <div className="h-24 rounded bg-gray-100"></div>
          <div className="h-24 rounded bg-gray-100"></div>

        </div>

      </div>

    </div>
  );
}