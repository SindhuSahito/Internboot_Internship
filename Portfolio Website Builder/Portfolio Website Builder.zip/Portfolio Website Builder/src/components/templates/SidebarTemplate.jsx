export default function SidebarTemplate() {
  return (
    <div className="bg-white rounded-xl shadow flex overflow-hidden">

      <div className="w-1/3 bg-gray-800 text-white p-4">

        <div className="w-14 h-14 rounded-full bg-white mx-auto"></div>

        <div className="h-3 bg-gray-500 rounded mt-4"></div>

        <div className="h-3 bg-gray-500 rounded mt-2"></div>

      </div>

      <div className="flex-1 p-4">

        <div className="h-4 bg-gray-300 rounded"></div>

        <div className="h-4 bg-gray-200 rounded mt-2"></div>

        <div className="grid grid-cols-2 gap-2 mt-5">

          <div className="h-20 bg-gray-100 rounded"></div>

          <div className="h-20 bg-gray-100 rounded"></div>

        </div>

      </div>

    </div>
  );
}