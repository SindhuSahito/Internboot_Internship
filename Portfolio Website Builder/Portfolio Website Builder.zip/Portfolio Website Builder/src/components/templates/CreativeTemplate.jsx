export default function CreativeTemplate() {
  return (
    <div className="bg-white rounded-xl shadow p-5">

      <div className="flex items-center gap-4">

        <div className="w-16 h-16 rounded-full bg-pink-300"></div>

        <div>

          <div className="w-32 h-4 bg-gray-300 rounded"></div>

          <div className="w-24 h-3 bg-gray-200 rounded mt-2"></div>

        </div>

      </div>

      <div className="grid grid-cols-2 gap-3 mt-6">

        <div className="bg-blue-100 rounded h-24"></div>
        <div className="bg-green-100 rounded h-24"></div>
        <div className="bg-yellow-100 rounded h-24"></div>
        <div className="bg-purple-100 rounded h-24"></div>

      </div>

    </div>
  );
}