import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";

import { useAuth } from "../../hooks/useAuth";
import {
  getUserProfile,
  updateUserProfile,
} from "../../services/profileService";

import Button from "../common/Button";
import Input from "../common/Input";

export default function ProfileForm() {
  const { currentUser } = useAuth();

  const [loading, setLoading] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
  } = useForm();

  useEffect(() => {
    async function loadProfile() {
      if (!currentUser) return;

      try {
        setLoading(true);

        const data = await getUserProfile(currentUser.uid);

        if (data) {
          reset({
            name: data.name || "",
            username: data.username || "",
            title: data.title || "",
            bio: data.bio || "",
            phone: data.phone || "",
            location: data.location || "",

            github: data.socialLinks?.github || "",
            linkedin: data.socialLinks?.linkedin || "",
            website: data.socialLinks?.website || "",
            twitter: data.socialLinks?.twitter || "",

            metaTitle: data.metaTitle || "",
            metaDescription: data.metaDescription || "",
          });
        }
      } catch (error) {
        console.error(error);
        toast.error("Failed to load profile");
      } finally {
        setLoading(false);
      }
    }

    loadProfile();
  }, [currentUser, reset]);

  async function onSubmit(data) {
    if (!currentUser) return;

    try {
      setLoading(true);

      console.log("Saving profile...");

      await updateUserProfile(currentUser.uid, {
        name: data.name,
        username: data.username,
        title: data.title,
        bio: data.bio,
        phone: data.phone,
        location: data.location,

        socialLinks: {
          github: data.github,
          linkedin: data.linkedin,
          website: data.website,
          twitter: data.twitter,
        },

        metaTitle: data.metaTitle,
        metaDescription: data.metaDescription,
      });

      console.log("Profile Saved!");

      toast.success("Profile updated successfully!");
    } catch (error) {
      console.error(error);
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      className="space-y-5"
    >
      <Input
        label="Full Name"
        name="name"
        register={register}
      />

      <Input
        label="Username"
        name="username"
        register={register}
      />

      <Input
        label="Professional Title"
        name="title"
        register={register}
      />

      <div>
        <label className="font-medium">
          Bio
        </label>

        <textarea
          rows="4"
          {...register("bio")}
          className="w-full border rounded-lg p-3 mt-2"
        />
      </div>

      <Input
        label="Phone"
        name="phone"
        register={register}
      />

      <Input
        label="Location"
        name="location"
        register={register}
      />

      <Input
        label="GitHub"
        name="github"
        register={register}
      />

      <Input
        label="LinkedIn"
        name="linkedin"
        register={register}
      />

      <Input
        label="Website"
        name="website"
        register={register}
      />

      <Input
        label="Twitter / X"
        name="twitter"
        register={register}
      />

      <div>
        <label className="block mb-2 font-medium">
          SEO Title
        </label>

        <input
          {...register("metaTitle")}
          placeholder="John Doe | Software Engineer"
          className="w-full border rounded-lg p-3"
        />
      </div>

      <div>
        <label className="block mb-2 font-medium">
          SEO Description
        </label>

        <textarea
          rows={3}
          {...register("metaDescription")}
          placeholder="Write a short description..."
          className="w-full border rounded-lg p-3"
        />
      </div>

      <Button
        type="submit"
        disabled={loading}
      >
        {loading ? "Saving..." : "Save Changes"}
      </Button>
    </form>
  );
}