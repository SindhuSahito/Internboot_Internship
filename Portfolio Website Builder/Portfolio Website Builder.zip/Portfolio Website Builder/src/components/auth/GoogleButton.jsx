import { FcGoogle } from "react-icons/fc";

export default function GoogleButton({ onClick, loading }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={loading}
      className="w-full border border-gray-300 rounded-lg py-3 flex items-center justify-center gap-3 hover:bg-gray-100 transition disabled:opacity-50"
    >
      <FcGoogle size={24} />
      Continue with Google
    </button>
  );
}