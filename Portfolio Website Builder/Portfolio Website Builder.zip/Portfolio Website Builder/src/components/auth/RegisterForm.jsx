import { useState } from "react";
import { useForm } from "react-hook-form";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";
import { useNavigate, Link } from "react-router-dom";
import toast from "react-hot-toast";

import { db } from "../../firebase/firebase";
import { useAuth } from "../../hooks/useAuth";
import Button from "../common/Button";
import Input from "../common/Input";

export default function RegisterForm() {
  const { signup } = useAuth();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = async (data) => {
    try {
      setLoading(true);

      // Create Authentication Account
      const userCredential = await signup(
        data.email,
        data.password
      );

      const user = userCredential.user;

      // Create Firestore User Profile
      await setDoc(doc(db, "users", user.uid), {
        uid: user.uid,
        name: data.name,
        username: data.username.toLowerCase(),
        email: data.email,

        bio: "",

        photoURL: "",

        template: "modern",

        socialLinks: {
          github: "",
          linkedin: "",
          twitter: "",
          website: "",
        },

        createdAt: serverTimestamp(),
      });

      toast.success("Account created successfully!");

      navigate("/dashboard");
    } catch (error) {
      console.error(error);
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      className="space-y-5"
    >
      <Input
        label="Full Name"
        name="name"
        placeholder="John Doe"
        register={register}
        error={errors.name}
      />

      <Input
        label="Username"
        name="username"
        placeholder="john"
        register={register}
        error={errors.username}
      />

      <Input
        label="Email"
        type="email"
        name="email"
        placeholder="john@gmail.com"
        register={register}
        error={errors.email}
      />

      <Input
        label="Password"
        type="password"
        name="password"
        placeholder="********"
        register={register}
        error={errors.password}
      />

      <Button type="submit" disabled={loading}>
        {loading ? "Creating Account..." : "Create Account"}
      </Button>

      <p className="text-center text-sm">
        Already have an account?{" "}
        <Link
          className="text-blue-600"
          to="/login"
        >
          Login
        </Link>
      </p>
    </form>
  );
}