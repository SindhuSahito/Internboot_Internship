import { useState } from "react";
import { useForm } from "react-hook-form";
import { Link, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

import Button from "../common/Button";
import Input from "../common/Input";
import GoogleButton from "./GoogleButton";
import { useAuth } from "../../hooks/useAuth";

export default function LoginForm() {
  const { login, googleLogin } = useAuth();

  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = async (data) => {
    try {
      setLoading(true);

      await login(data.email, data.password);

      toast.success("Welcome back!");

      navigate("/dashboard");
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      setLoading(true);

      await googleLogin();

      toast.success("Login Successful!");

      navigate("/dashboard");
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      className="space-y-5"
    >
      <Input
        label="Email"
        type="email"
        name="email"
        placeholder="john@gmail.com"
        register={register}
        error={errors.email}
      />

      <Input
        label="Password"
        type="password"
        name="password"
        placeholder="********"
        register={register}
        error={errors.password}
      />

      <Button
        type="submit"
        disabled={loading}
      >
        {loading ? "Logging In..." : "Login"}
      </Button>

      <div className="text-center text-gray-500">
        OR
      </div>

      <GoogleButton
        onClick={handleGoogleLogin}
        loading={loading}
      />

      <p className="text-center text-sm">
        Don't have an account?{" "}
        <Link
          to="/register"
          className="text-blue-600"
        >
          Register
        </Link>
      </p>
    </form>
  );
}