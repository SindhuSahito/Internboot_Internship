export default function CreativePortfolio({ user, projects }) {
  return (
    <div className="min-h-screen bg-gradient-to-r from-pink-100 to-blue-100 p-10">

      <div className="text-center mb-12">

        <h1 className="text-6xl font-extrabold">
          {user.name}
        </h1>

        <p className="text-xl mt-3">
          {user.bio}
        </p>

      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">

        {projects.map((project) => (
          <div
            key={project.id}
            className="bg-white rounded-xl p-5 shadow-lg hover:scale-105 transition"
          >
            {project.image && (
              <img
                src={project.image}
                alt={project.title}
                className="rounded-lg mb-4 h-48 w-full object-cover"
              />
            )}

            <h2 className="text-2xl font-bold">
              {project.title}
            </h2>

            <p className="mt-3">
              {project.description}
            </p>
          </div>
        ))}

      </div>

    </div>
  );
}