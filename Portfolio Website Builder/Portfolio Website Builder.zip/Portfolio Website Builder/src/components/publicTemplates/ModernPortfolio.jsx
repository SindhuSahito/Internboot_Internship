export default function ModernPortfolio({ user, projects }) {
  return (
    <div className="max-w-6xl mx-auto p-8">
      <div className="text-center">
        {user.profileImage && (
          <img
            src={user.profileImage}
            alt={user.name}
            className="w-36 h-36 rounded-full mx-auto object-cover border-4 border-blue-500"
          />
        )}

        <h1 className="text-5xl font-bold mt-6">{user.name}</h1>

        <p className="text-gray-500 mt-3">{user.bio}</p>
      </div>

      <h2 className="text-3xl font-bold mt-16 mb-8">
        Projects
      </h2>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((project) => (
          <div key={project.id} className="bg-white rounded-xl shadow overflow-hidden">
            {project.image && (
              <img
                src={project.image}
                alt={project.title}
                className="w-full h-48 object-cover"
              />
            )}

            <div className="p-5">
              <h3 className="text-xl font-bold">{project.title}</h3>
              <p className="text-gray-600 mt-2">{project.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}