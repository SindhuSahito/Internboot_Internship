export default function SidebarPortfolio({ user, projects }) {
  return (
    <div className="flex min-h-screen">

      <aside className="w-72 bg-gray-900 text-white p-8">

        {user.profileImage && (
          <img
            src={user.profileImage}
            alt={user.name}
            className="w-32 h-32 rounded-full mx-auto"
          />
        )}

        <h2 className="text-3xl text-center mt-5">
          {user.name}
        </h2>

        <p className="text-center mt-3">
          {user.bio}
        </p>

      </aside>

      <main className="flex-1 p-10">

        <h2 className="text-3xl font-bold mb-8">
          Projects
        </h2>

        <div className="space-y-6">

          {projects.map((project) => (
            <div
              key={project.id}
              className="bg-white rounded-xl shadow p-5"
            >
              <h3 className="text-2xl font-bold">
                {project.title}
              </h3>

              <p className="mt-2 text-gray-600">
                {project.description}
              </p>
            </div>
          ))}

        </div>

      </main>

    </div>
  );
}