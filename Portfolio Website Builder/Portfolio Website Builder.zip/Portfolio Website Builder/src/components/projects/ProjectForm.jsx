import { useState } from "react";
import { useForm } from "react-hook-form";

export default function ProjectForm({ onSubmit, defaultValues = {} }) {
  const [image, setImage] = useState(null);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    defaultValues,
  });

  const submitHandler = (data) => {
    onSubmit({
      ...data,
      image,
    });

    reset();
    setImage(null);
  };

  return (
    <form
      onSubmit={handleSubmit(submitHandler)}
      className="space-y-5"
    >
      {/* Project Title */}
      <div>
        <label className="block mb-2 font-medium text-gray-700">
          Project Title
        </label>

        <input
          {...register("title", {
            required: "Project title is required",
          })}
          type="text"
          placeholder="Enter project title"
          className="w-full border rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />

        {errors.title && (
          <p className="text-red-500 text-sm mt-1">
            {errors.title.message}
          </p>
        )}
      </div>

      {/* Description */}
      <div>
        <label className="block mb-2 font-medium text-gray-700">
          Description
        </label>

        <textarea
          {...register("description", {
            required: "Description is required",
          })}
          rows={5}
          placeholder="Write a short description..."
          className="w-full border rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />

        {errors.description && (
          <p className="text-red-500 text-sm mt-1">
            {errors.description.message}
          </p>
        )}
      </div>

      {/* Project Image */}
      <div>
        <label className="block mb-2 font-medium text-gray-700">
          Project Image
        </label>

        <input
          type="file"
          accept="image/*"
          onChange={(e) => setImage(e.target.files[0])}
          className="w-full border rounded-lg p-3 cursor-pointer"
        />
      </div>

      {/* GitHub URL */}
      <div>
        <label className="block mb-2 font-medium text-gray-700">
          GitHub Repository
        </label>

        <input
          {...register("github")}
          type="url"
          placeholder="https://github.com/username/project"
          className="w-full border rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Live Demo URL */}
      <div>
        <label className="block mb-2 font-medium text-gray-700">
          Live Demo
        </label>

        <input
          {...register("liveDemo")}
          type="url"
          placeholder="https://yourproject.com"
          className="w-full border rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Tags */}
      <div>
        <label className="block mb-2 font-medium text-gray-700">
          Tags
        </label>

        <input
          {...register("tags")}
          type="text"
          placeholder="React, Firebase, Tailwind"
          className="w-full border rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />

        <p className="text-xs text-gray-500 mt-1">
          Separate tags with commas.
        </p>
      </div>

      {/* Featured */}
      <div className="flex items-center gap-3">
        <input
          type="checkbox"
          {...register("featured")}
          className="w-4 h-4"
        />

        <label className="font-medium text-gray-700">
          Mark as Featured Project
        </label>
      </div>

      {/* Submit */}
      <button
        type="submit"
        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-lg transition"
      >
        Save Project
      </button>
    </form>
  );
}