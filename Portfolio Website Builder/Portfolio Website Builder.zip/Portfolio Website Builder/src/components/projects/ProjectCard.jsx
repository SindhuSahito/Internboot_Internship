export default function ProjectCard({
  project,
  onEdit,
  onDelete,
}) {
  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition">

      {project.image && (
        <img
          src={project.image}
          alt={project.title}
          className="w-full h-52 object-cover"
        />
      )}

      <div className="p-5">

        <div className="flex justify-between items-start">

          <h2 className="text-xl font-bold">
            {project.title}
          </h2>

          {project.featured && (
            <span className="bg-yellow-400 text-xs px-2 py-1 rounded">
              ⭐ Featured
            </span>
          )}

        </div>

        <p className="text-gray-600 mt-3 line-clamp-3">
          {project.description}
        </p>

        {project.tags?.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-4">

            {project.tags.map((tag) => (
              <span
                key={tag}
                className="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs"
              >
                {tag}
              </span>
            ))}

          </div>
        )}

        <div className="flex gap-3 mt-6">

          {project.github && (
            <a
              href={project.github}
              target="_blank"
              rel="noreferrer"
              className="bg-gray-800 hover:bg-gray-900 text-white px-4 py-2 rounded-lg"
            >
              GitHub
            </a>
          )}

          {project.liveDemo && (
            <a
              href={project.liveDemo}
              target="_blank"
              rel="noreferrer"
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg"
            >
              Live Demo
            </a>
          )}

        </div>

        <div className="flex gap-3 mt-5">

          <button
            onClick={() => onEdit(project)}
            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg"
          >
            Edit
          </button>

          <button
            onClick={() => onDelete(project.id)}
            className="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 rounded-lg"
          >
            Delete
          </button>

        </div>

      </div>

    </div>
  );
}