export default function Input({
  label,
  type = "text",
  register,
  name,
  placeholder,
  error,
}) {
  return (
    <div className="space-y-2">
      <label className="block font-medium">{label}</label>

      <input
        type={type}
        placeholder={placeholder}
        {...register(name, {
          required: `${label} is required`,
        })}
        className="w-full border rounded-lg px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500"
      />

      {error && (
        <p className="text-red-500 text-sm">
          {error.message}
        </p>
      )}
    </div>
  );
}