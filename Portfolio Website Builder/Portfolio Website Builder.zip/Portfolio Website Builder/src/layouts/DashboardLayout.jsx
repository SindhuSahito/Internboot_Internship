import { Outlet, NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";

export default function DashboardLayout() {
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();

  async function handleLogout() {
    try {
      await logout();
      navigate("/login");
    } catch (error) {
      console.error(error);
    }
  }

  const linkClass = ({ isActive }) =>
    `block px-4 py-3 rounded-lg transition ${
      isActive
        ? "bg-blue-600 text-white"
        : "text-gray-700 hover:bg-gray-100"
    }`;

  return (
    <div className="min-h-screen flex bg-gray-100">
      {/* Sidebar */}
      <aside className="w-64 bg-white shadow-lg p-6">
        <h1 className="text-2xl font-bold mb-8">
          Portfolio Builder
        </h1>

        <nav className="space-y-2">
          <NavLink to="/dashboard" end className={linkClass}>
            Dashboard
          </NavLink>

          <NavLink
            to="/dashboard/profile"
            className={linkClass}
          >
            Profile
          </NavLink>

          <NavLink
            to="/dashboard/projects"
            className={linkClass}
          >
            Projects
          </NavLink>

          <NavLink
            to="/dashboard/templates"
            className={linkClass}
          >
            Templates
          </NavLink>

          <NavLink
            to={`/portfolio/${
              currentUser?.displayName || currentUser?.uid
            }`}
            className={linkClass}
          >
            Portfolio
          </NavLink>
        </nav>

        <button
          onClick={handleLogout}
          className="mt-10 w-full bg-red-500 hover:bg-red-600 text-white py-3 rounded-lg"
        >
          Logout
        </button>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8">
        <div className="bg-white rounded-xl shadow p-6 min-h-[80vh]">
          <Outlet />
        </div>
      </main>
    </div>
  );
}