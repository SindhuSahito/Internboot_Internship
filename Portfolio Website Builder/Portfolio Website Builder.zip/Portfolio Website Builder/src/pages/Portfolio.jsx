import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Helmet } from "react-helmet-async";

import {
  getPortfolioByUsername,
  getPortfolioProjects,
} from "../services/portfolioService";

import ModernPortfolio from "../components/publicTemplates/ModernPortfolio";
import CreativePortfolio from "../components/publicTemplates/CreativePortfolio";
import SidebarPortfolio from "../components/publicTemplates/SidebarPortfolio";

export default function Portfolio() {
  const { username } = useParams();

  const [user, setUser] = useState(null);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPortfolio();
  }, [username]);

  async function loadPortfolio() {
    try {
      const profile = await getPortfolioByUsername(username);

      if (!profile) {
        setLoading(false);
        return;
      }

      setUser(profile);

      const projectList = await getPortfolioProjects(profile.id);

      setProjects(projectList);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex justify-center items-center text-2xl font-semibold">
        Loading Portfolio...
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex justify-center items-center text-3xl font-bold">
        Portfolio Not Found
      </div>
    );
  }

  const template = user.selectedTemplate || "modern";

  return (
    <>
      <Helmet>
        <title>
          {user.metaTitle || `${user.name} | Portfolio`}
        </title>

        <meta
          name="description"
          content={
            user.metaDescription ||
            user.bio ||
            "Personal Portfolio"
          }
        />

        <meta
          property="og:title"
          content={
            user.metaTitle ||
            `${user.name} | Portfolio`
          }
        />

        <meta
          property="og:description"
          content={
            user.metaDescription ||
            user.bio ||
            "Personal Portfolio"
          }
        />

        <meta
          property="og:image"
          content={user.profileImage || ""}
        />

        <meta property="og:type" content="website" />
      </Helmet>

      {template === "modern" && (
        <ModernPortfolio
          user={user}
          projects={projects}
        />
      )}

      {template === "creative" && (
        <CreativePortfolio
          user={user}
          projects={projects}
        />
      )}

      {template === "sidebar" && (
        <SidebarPortfolio
          user={user}
          projects={projects}
        />
      )}
    </>
  );
}