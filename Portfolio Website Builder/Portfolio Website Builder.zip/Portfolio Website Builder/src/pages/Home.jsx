import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center px-6">
      <div className="text-center max-w-3xl">
        <h1 className="text-5xl md:text-6xl font-bold text-slate-800">
          Portfolio Website Builder
        </h1>

        <p className="mt-6 text-lg text-slate-600">
          Create, customize, and publish your professional portfolio with
          multiple templates, project management, and a personalized public
          profile.
        </p>

        <div className="mt-10 flex justify-center gap-4">
          <Link
            to="/register"
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition"
          >
            Get Started
          </Link>

          <Link
            to="/login"
            className="border border-slate-400 px-6 py-3 rounded-lg hover:bg-slate-200 transition"
          >
            Login
          </Link>
        </div>
      </div>
    </div>
  );
}